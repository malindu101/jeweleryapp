const cookieConsent = localStorage.getItem("cookieConsent");
const trackingEnabled = cookieConsent === "accepted";

let colorTimers = {};
let materialTimers = {};

let currentColor = null;
let currentMaterial = null;
let colorStartTime = null;
let materialStartTime = null;

let colorClicked = false;
let materialClicked = false;

window.addEventListener("beforeunload", function (e) {
  // Standard message for most modern browsers
  const confirmationMessage = "Are you sure you want to leave the configurator?";
  
  
  e.returnValue = confirmationMessage;
  return confirmationMessage;
});

function now() {
  return new Date().getTime();
}

function trackColor(materialName) {
  if (!trackingEnabled) return;
  colorClicked = true;
  const timeNow = now();

  if (currentColor !== null && colorStartTime !== null && colorTimers[currentColor]) {
    colorTimers[currentColor] += (timeNow - colorStartTime);
  }

  if (!colorTimers[materialName]) {
    colorTimers[materialName] = 0;
  }

  currentColor = materialName;
  colorStartTime = timeNow;
}

function trackMaterial(materialName) {
  if (!trackingEnabled) return;
  materialClicked = true;
  const timeNow = now();

  if (currentMaterial !== null && materialStartTime !== null && materialTimers[currentMaterial]) {
    materialTimers[currentMaterial] += (timeNow - materialStartTime);
  }

  if (!materialTimers[materialName]) {
    materialTimers[materialName] = 0;
  }

  currentMaterial = materialName;
  materialStartTime = timeNow;
}

function changeColor(partOne, materialOne) {
  trackColor(materialOne);
  Unlimited3D.changeMaterials({
    partObjects: [{ parts: [partOne], material: materialOne }]
  });
}

function setGoldColor() {
  trackMaterial("Gold");
  Unlimited3D.changeMaterialColor({ material: "Silver_2", color: "#FFD700" });
}

function setSilverColor() {
  trackMaterial("Silver");
  Unlimited3D.changeMaterialColor({ material: "Silver_2", color: "#C0C0C0" });
}

function setRoseGoldColor() {
  trackMaterial("Rose Gold");
  Unlimited3D.changeMaterialColor({ material: "Silver_2", color: "#B76E79" });
}

function onInput(element) {
  Unlimited3D.updateOverlay({
    overlay: 'Metallic',
    overlayEntry: 'Text',
    options: { text: element.value }
  });
}

function activateModifier() {
  Unlimited3D.activateModifier({ modifier: modifiers[modifierIndex] });
  modifierIndex = (modifierIndex + 1) % modifiers.length;
}

let modifiers = ['Reset', 'Start', 'Hand'];
let modifierIndex = 0;

function getSnapshot() {
  Unlimited3D.getSnapshot({ width: 1920, height: 1080 }, function (error, result) {
    if (!error && result) {
      const link = document.createElement('a');
      link.href = result;
      link.download = 'snapshot.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      console.error("Snapshot error:", error);
    }
  });
}

function finalizeTimers() {
  const timeNow = now();
  if (currentColor && colorStartTime && colorTimers[currentColor]) {
    colorTimers[currentColor] += timeNow - colorStartTime;
    colorStartTime = null;
  }
  if (currentMaterial && materialStartTime && materialTimers[currentMaterial]) {
    materialTimers[currentMaterial] += timeNow - materialStartTime;
    materialStartTime = null;
  }
}

function showTopSelections() {
  if (!trackingEnabled) return;

  finalizeTimers();

  const topColors = colorClicked
    ? Object.entries(colorTimers).sort((a, b) => b[1] - a[1]).map(item => item[0].replace("Diamond_", ""))
    : null;

  const topMaterials = materialClicked
    ? Object.entries(materialTimers).sort((a, b) => b[1] - a[1]).map(item => item[0])
    : null;

  sendToDatabase(topColors, topMaterials);
}

function sendToDatabase(colors, materials) {
  fetch("save_behavior.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ colors, materials }),
  })
  .then(response => response.json())
  .then(data => console.log("Saved:", data))
  .catch(error => console.error("Save failed:", error));
}

function sendNullToDatabase() {
  fetch("save_behavior.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ colors: null, materials: null }),
  })
  .then(response => response.json())
  .then(data => console.log("Null test:", data))
  .catch(error => console.error("Null test failed:", error));
}

window.addEventListener("beforeunload", function () {
  if (!trackingEnabled) return;

  finalizeTimers();

  const topColors = colorClicked
    ? Object.entries(colorTimers).sort((a, b) => b[1] - a[1]).map(item => item[0].replace("Diamond_", ""))
    : null;

  const topMaterials = materialClicked
    ? Object.entries(materialTimers).sort((a, b) => b[1] - a[1]).map(item => item[0])
    : null;

  if (topColors || topMaterials) {
    navigator.sendBeacon("save_behavior.php",
      new Blob([JSON.stringify({
        colors: topColors,
        materials: topMaterials
      })], { type: "application/json" })
    );
  }
});

window.onload = function () {
  const options = {
    distID: "latest",
    solution3DName: "demo-ring-new-shader-configurator",
    projectName: "tests",
    solution3DID: "47143",
    containerID: "container3d_replace"
  };

  Unlimited3D.init(options, {}, function (error, status) {
    if (error || !status) {
      console.error("3D Viewer failed to load:", error);
      return;
    }
    document.getElementById('loadingContent').style.display = "none";
  });
};

document.getElementById('ar-button').addEventListener('click', function (e) {
  e.preventDefault();
  document.querySelector('.QRcode').style.display = 'block';
  new QRCode(document.getElementById("qrCodeImg"), {
    text: window.location.href,
    width: 180,
    height: 180
  });
});

document.getElementById('closeQRcode').addEventListener('click', function (e) {
  e.preventDefault();
  document.querySelector('.QRcode').style.display = 'none';
  document.getElementById("qrCodeImg").innerHTML = '';
});
