<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "user_preferences";

// Connect to the database
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//  Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

//  Extract up to 3 colors and 3 materials safely
$color1 = isset($data['colors'][0]) ? $data['colors'][0] : null;
$color2 = isset($data['colors'][1]) ? $data['colors'][1] : null;
$color3 = isset($data['colors'][2]) ? $data['colors'][2] : null;

$material1 = isset($data['materials'][0]) ? $data['materials'][0] : null;
$material2 = isset($data['materials'][1]) ? $data['materials'][1] : null;
$material3 = isset($data['materials'][2]) ? $data['materials'][2] : null;

//  Prepare SQL insert
$stmt = $conn->prepare("INSERT INTO user_behavior (top_color_1, top_color_2, top_color_3, top_material_1, top_material_2, top_material_3) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $color1, $color2, $color3, $material1, $material2, $material3);

// Execute and respond
if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
