<?php
header('Content-Type: application/json');

// ✅ DB connection
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'dashboard'; // update this

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Database connection failed']));
}

// ✅ Fetch the first row
$sql = "SELECT * FROM dashboard_data LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // ✅ Decode JSON fields
    $sales_weekly = json_decode($row['sales_weekly'], true);
    $category_sales = json_decode($row['category_sales'], true);

    $data = [
        'total_sales' => (int)$row['total_sales'],
        'ongoing_orders' => (int)$row['ongoing_orders'],
        'completed_orders' => (int)$row['completed_orders'],
        'refunded' => (int)$row['refunded'],
        'sales_weekly' => $sales_weekly,
        'category_sales' => $category_sales
    ];

    echo json_encode($data);
} else {
    echo json_encode(['error' => 'No data found']);
}

$conn->close();
?>
