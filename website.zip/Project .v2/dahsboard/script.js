fetch('data.php')
  .then(response => response.json())
  .then(data => {
    console.log('Dashboard Data:', data);

    // ✅ Update tile values
    document.querySelector('.card.green h1').textContent = data.total_sales;
    document.querySelector('.card.yellow h1').textContent = data.ongoing_orders;
    document.querySelector('.card.blue h1').textContent = data.completed_orders;
    document.querySelector('.card.red h1').textContent = data.refunded;

    // ✅ Revenue chart
    new Chart(document.getElementById('revenueChart'), {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
          label: 'Revenue',
          data: data.sales_weekly,
          borderColor: '#007bff',
          backgroundColor: '#e6f0ff',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    // ✅ Category chart
    new Chart(document.getElementById('salesChart'), {
      type: 'doughnut',
      data: {
        labels: data.category_sales.labels,
        datasets: [{
          data: data.category_sales.values,
          backgroundColor: ['#FF6B6B', '#28B463', '#4C6EF5', '#F4D03F'],
          borderWidth: 1
        }]
      },
      options: {
        plugins: {
          legend: {
            position: 'bottom',
            labels: { usePointStyle: true }
          }
        }
      }
    });
  })
  .catch(error => {
    console.error('Failed to load dashboard data:', error);
  });
